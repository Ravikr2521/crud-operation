
import React, { useEffect, useState } from 'react'
import Btn, { Editdata,Viewbtn } from './Button'
import DeleteIcon from '@mui/icons-material/Delete';
import './crud.css';


export default function Dash(){
    const [Employ, SetEmploy] = useState([])
    const [Update, setUpdate] = useState({});
    const [search, setSearch]=useState("")

    useEffect(()=>
    {
        loaduser();
    },[])
    
   
        
    const loaduser  = () => {
       fetch('http://localhost:3002/employee').then((response) => response.json().then((data) => {
           SetEmploy(data)
       }))
    }
    const deleteData = (id) => {

        const requestOptions = {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },

        };
        fetch(`http://localhost:3002/employee/${id}`, requestOptions)
            .then(response => response.json())
            .then(() => {
                alert(" Deleted succefully");
                newData();
            }
            );
    }

console.log(Employ)

    const newData = () => {
        loaduser();
    }

    return(
    <>

<div className="save-data">
            <div className="mid-save"><Btn call={newData}/></div>
        </div>
        <div className="box-table">


            <div className="mid-table">
                <input type="text"  placeholder='Search'
                 onChange={(e) => {setSearch(e.target.value) }}/> 

               
                    <table className='table'>
                        <thead>
                            <tr >
                                <th>S.No</th>
                                <th>ID</th>
                                <th>Employee Name</th>
                                <th>Employee mail</th>
                                <th>Employee Age</th>
                                <th>Employee Salary</th>

                                <th>EDIT</th>
                                <th>DELETE</th>
                                <th>VIEW</th>

                                
                            </tr>

                        </thead>
                        <tbody>
                            {Employ.filter((v)=>{
                                if(search===""){
                                    return v;
                    
                                }
                                else if(v.employee_name.toLowerCase().includes(search.toLowerCase()) ||
                                v.employee_email.toLowerCase().includes(search.toLocaleLowerCase) ||
                                v.employee_age.toLocaleLowerCase().includes(search.toLocaleLowerCase) ||
                                v.employee_salary.toLocaleLowerCase().includes(search.toLocaleLowerCase)){
                                    return v;
                                }
                            })
                            .map((v,i) =>
                            <tr key={v.id}>
                                <th>{i+1}</th>
                                <th>{v.id}</th>
                                <th>{v.employee_name}</th>
                                <th>{v.employee_email}</th>
                                <th>{v.employee_age}</th>
                                <th>{v.employee_salary}</th>                        
                                <th onClick={()=>{setUpdate(v)}}><Editdata call={newData} obj={Update}/></th>
                                <th><button className="dlt_btn" onClick={() => { deleteData(v.id) }}><DeleteIcon /></button> </th>
                                <th onClick={()=>{setUpdate(v)}}><Viewbtn call={newData} obj={Update}/></th>


                            </tr>
                           )}
                        </tbody>
                    </table>

            
               </div>
               </div>

    </>
    )
}