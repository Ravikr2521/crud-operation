export default function Home(){
    return(
        <>
        <h1>Welcome to home Page</h1>
        </>
    )
}
