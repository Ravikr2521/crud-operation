export default function About(){
    return(
        <>
        <h1>Welcome to  About Page</h1>
        </>
    )
}